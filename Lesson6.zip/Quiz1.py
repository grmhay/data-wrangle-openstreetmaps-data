__author__ = 'grmhay'
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Your task is to use the iterative parsing to process the map file and
find out not only what tags are there, but also how many, to get the
feeling on how much of which data you can expect to have in the map.
The output should be a dictionary with the tag name as the key
and number of times this tag can be encountered in the map as value.

Note that your code will be tested with a different data file than the 'example.osm'
"""
import xml.etree.ElementTree as ET
import pprint

def count_tags(filename):
        # Initialize a dictionary to hold the tags and their counts in
        tags = {}

        for event, elem in ET.iterparse(filename, events=("start",)):

                # If the tag is already found in the dictionary, increment the count value
                if tags.has_key(elem.tag):
                   tags[elem.tag] += 1
                else:
                # Then the tag isn't found and it needs to go in the dictionary with an initial value of 1
                   tags[elem.tag] = 1


        pprint.pprint(tags)
        return tags


def test():

    tags = count_tags('example.osm')
    pprint.pprint(tags)
    assert tags == {'bounds': 1,
                     'member': 3,
                     'nd': 4,
                     'node': 20,
                     'osm': 1,
                     'relation': 1,
                     'tag': 7,
                     'way': 1}



if __name__ == "__main__":
    test()